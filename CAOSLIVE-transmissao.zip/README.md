# CAOSLIVE! Transmissão

WebRTC + WebSocket. Para publicar no Render: Build `npm install`, Start `npm start`.