const $=id=>document.getElementById(id);
const modal=$("modal"), posts=$("posts"), grid=$("memoryGrid");
let data=JSON.parse(localStorage.getItem("caoslive_social")||"null")||[
 {id:1,author:"CAOSLIVE!",text:"Bem-vindo ao mural da comunidade! Aqui você pode compartilhar momentos, novidades e guardar suas melhores recordações.",date:"Agora",image:"",memory:true}
];
function save(){localStorage.setItem("caoslive_social",JSON.stringify(data))}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function render(){
 posts.innerHTML=data.slice().reverse().map(p=>`
 <article class="post">
  <div class="postHead"><div class="mini">${esc((p.author||"U").slice(0,2).toUpperCase())}</div><div><b>${esc(p.author||"Anônimo")}</b><small>${esc(p.date)}</small></div></div>
  <p>${esc(p.text)}</p>${p.image?`<img src="${esc(p.image)}" onerror="this.style.display='none'">`:""}
  <div class="actions"><button onclick="toggleMemory(${p.id})">${p.memory?"★ Salva nas recordações":"☆ Salvar recordação"}</button><button onclick="removePost(${p.id})">Excluir</button></div>
 </article>`).join("");
 const memories=data.filter(p=>p.memory&&p.image);
 grid.innerHTML=memories.length?memories.slice().reverse().map(p=>`<div class="memory"><img src="${esc(p.image)}"><div class="caption"><b>${esc(p.author)}</b><br>${esc(p.text.slice(0,70))}</div></div>`).join(""):`<div class="empty">As recordações com fotos aparecerão aqui.</div>`;
}
function open(){modal.classList.add("show");$("author").focus()}
function close(){modal.classList.remove("show")}
["newPost","newPostSide","newPostTop"].forEach(id=>$(id).onclick=open);
$("close").onclick=close;
modal.onclick=e=>{if(e.target===modal)close()};
$("publish").onclick=()=>{
 const author=$("author").value.trim()||"Anônimo", text=$("text").value.trim(), image=$("image").value.trim();
 if(!text){alert("Escreva alguma coisa antes de publicar.");return}
 data.push({id:Date.now(),author,text,image,memory:$("remember").checked,date:new Date().toLocaleString("pt-BR",{dateStyle:"short",timeStyle:"short"})});
 save();render();close();$("text").value="";$("image").value="";
};
window.toggleMemory=id=>{const p=data.find(x=>x.id===id);if(p){p.memory=!p.memory;save();render()}};
window.removePost=id=>{if(confirm("Excluir esta postagem?")){data=data.filter(x=>x.id!==id);save();render()}};
render();